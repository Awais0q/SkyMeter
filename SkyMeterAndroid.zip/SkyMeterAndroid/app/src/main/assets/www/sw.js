/* SkyMeter Service Worker — offline shell cache */
const CACHE = 'skymeter-v1';
const ASSETS = [
  './SkyMeter.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-48.png',
  './apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  // Network-first for API/radar/tiles; cache-first for app shell
  const url = new URL(req.url);
  const isShell =
    url.origin === self.location.origin &&
    (ASSETS.some((a) => url.pathname.endsWith(a.replace('./', ''))) ||
      url.pathname.endsWith('SkyMeter.html') ||
      url.pathname.endsWith('/'));

  if (isShell) {
    event.respondWith(
      caches.match(req).then((cached) => cached || fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
        return res;
      }).catch(() => caches.match('./SkyMeter.html')))
    );
  }
});
