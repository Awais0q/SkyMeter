package com.skymeter.app;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

/**
 * Native OpenStreetMap map (osmdroid MAPNIK tiles).
 * Launch with optional extras: lat, lon, zoom, title
 */
public class OsmMapActivity extends AppCompatActivity {

    private MapView map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Required user-agent for OSM tile servers
        Configuration.getInstance().load(
                getApplicationContext(),
                PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
        );
        Configuration.getInstance().setUserAgentValue(getPackageName());

        setContentView(R.layout.activity_osm_map);

        map = findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.setTilesScaledToDpi(true);

        double lat = getIntent().getDoubleExtra("lat", 33.6844); // Islamabad default
        double lon = getIntent().getDoubleExtra("lon", 73.0479);
        double zoom = getIntent().getDoubleExtra("zoom", 9.0);
        String title = getIntent().getStringExtra("title");
        if (title == null || title.isEmpty()) title = "SkyMeter";

        map.getController().setZoom(zoom);
        GeoPoint start = new GeoPoint(lat, lon);
        map.getController().setCenter(start);

        Marker marker = new Marker(map);
        marker.setPosition(start);
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setTitle(title);
        map.getOverlays().add(marker);
        map.invalidate();

        ImageButton close = findViewById(R.id.btnCloseMap);
        if (close != null) {
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map != null) map.onPause();
    }
}
