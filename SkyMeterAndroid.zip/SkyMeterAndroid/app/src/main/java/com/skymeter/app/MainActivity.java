package com.skymeter.app;

import android.Manifest;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import android.location.Address;
import android.location.Geocoder;
import android.content.Intent;
import android.net.Uri;
import android.content.res.Configuration;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import org.json.JSONObject;
import java.util.List;
import java.util.Locale;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int REQ_LOCATION = 1001;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageLoaded = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        // Dark bg so flash is not pure black/white mismatch
        webView.setBackgroundColor(0xFF0F172A);
        // HARDWARE can black-screen on some devices after pause; SOFTWARE more stable
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(true);
        // Never force WebView dark — follow OS / our JS theme only
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                settings.setForceDark(WebSettings.FORCE_DARK_OFF);
            }
        } catch (Exception ignored) {}
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                // algorithmic darkening off
                settings.setAlgorithmicDarkeningAllowed(false);
            }
        } catch (Exception ignored) {}
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowFileAccessFromFileURLs(true);
        // Keep DOM active
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setOffscreenPreRaster(true);
        }

        
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openOsmMap(double lat, double lon, double zoom, String title) {
                runOnUiThread(() -> {
                    Intent i = new Intent(MainActivity.this, OsmMapActivity.class);
                    i.putExtra("lat", lat);
                    i.putExtra("lon", lon);
                    i.putExtra("zoom", zoom > 0 ? zoom : 9.0);
                    i.putExtra("title", title != null ? title : "SkyMeter");
                    startActivity(i);
                });
            }
            @android.webkit.JavascriptInterface
            public boolean isNightMode() {
                return isSystemNightMode();
            }
            @android.webkit.JavascriptInterface
            public void requestNotifications() {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 33) {
                        if (ContextCompat.checkSelfPermission(MainActivity.this,
                                "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{"android.permission.POST_NOTIFICATIONS"}, 1002);
                        }
                    }
                });
            }

            /**
             * WORKING Native Android Geocoder bridge.
             * Called from JS: SkyMeterNative.reverseGeocode(lat, lon)
             * Uses Geocoder.getFromLocation — same platform API many weather apps use.
             * Returns JSON. Empty fields if unavailable. Never changes GPS coords.
             */
            @android.webkit.JavascriptInterface
            public String reverseGeocode(final double lat, final double lon) {
                JSONObject err = new JSONObject();
                try {
                    if (!Geocoder.isPresent()) {
                        err.put("error", "geocoder_not_present");
                        err.put("name", "");
                        return err.toString();
                    }
                    final AtomicReference<List<Address>> ref = new AtomicReference<>(null);
                    final AtomicReference<String> errMsg = new AtomicReference<>(null);
                    Geocoder geocoder = new Geocoder(MainActivity.this, Locale.ENGLISH);

                    if (Build.VERSION.SDK_INT >= 33) {
                        final CountDownLatch latch = new CountDownLatch(1);
                        geocoder.getFromLocation(lat, lon, 5, new Geocoder.GeocodeListener() {
                            @Override
                            public void onGeocode(java.util.List<Address> addresses) {
                                ref.set(addresses);
                                latch.countDown();
                            }
                            @Override
                            public void onError(String errorMessage) {
                                errMsg.set(errorMessage != null ? errorMessage : "geocode_error");
                                latch.countDown();
                            }
                        });
                        boolean ok = latch.await(8, TimeUnit.SECONDS);
                        if (!ok) {
                            err.put("error", "geocode_timeout");
                            err.put("name", "");
                            return err.toString();
                        }
                        if (errMsg.get() != null) {
                            err.put("error", errMsg.get());
                            err.put("name", "");
                            return err.toString();
                        }
                    } else {
                        @SuppressWarnings("deprecation")
                        List<Address> legacy = geocoder.getFromLocation(lat, lon, 5);
                        ref.set(legacy);
                    }

                    List<Address> list = ref.get();
                    if (list == null || list.isEmpty()) {
                        err.put("error", "no_results");
                        err.put("name", "");
                        return err.toString();
                    }

                    Address a0 = list.get(0);
                    String subLocality = a0.getSubLocality();
                    String locality = a0.getLocality();
                    String feature = a0.getFeatureName();
                    String thoroughfare = a0.getThoroughfare();
                    String premises = a0.getPremises();
                    String subAdmin = a0.getSubAdminArea();
                    String admin = a0.getAdminArea();
                    String country = a0.getCountryName();

                    // Plus Code detector (e.g. 26WF+G8Q) — never use as place name
                    java.util.function.Predicate<String> isPlus = s -> {
                        if (s == null) return true;
                        String t = s.trim().replace(" ", "");
                        return t.matches("(?i)^[A-Z0-9]{4,}\\+[A-Z0-9]{2,}$")
                            || t.matches("(?i)^[0-9]{2,}[A-Z]{2,}\\+[A-Z0-9]+$");
                    };

                    // Build best local name from hierarchy (dynamic, no hardcode)
                    String name = "";
                    if (subLocality != null && subLocality.trim().length() > 1 && !isPlus.test(subLocality)) {
                        name = subLocality.trim();
                    } else if (premises != null && premises.trim().length() > 1 && !isPlus.test(premises)) {
                        name = premises.trim();
                    } else if (feature != null && feature.trim().length() > 1
                            && !isPlus.test(feature)
                            && !feature.matches("^[0-9\\-\\s]+$")
                            && (locality == null || !feature.equalsIgnoreCase(locality))
                            && (thoroughfare == null || !feature.equalsIgnoreCase(thoroughfare))) {
                        name = feature.trim();
                    } else if (locality != null && locality.trim().length() > 1 && !isPlus.test(locality)) {
                        name = locality.trim();
                    } else if (subAdmin != null && subAdmin.trim().length() > 1 && !isPlus.test(subAdmin)
                            && !subAdmin.toLowerCase(Locale.ENGLISH).contains("tehsil")
                            && !subAdmin.toLowerCase(Locale.ENGLISH).contains("district")) {
                        name = subAdmin.trim();
                    }

                    // Address lines: skip Plus Code first segment ("26WF+G8Q, Village Name, ...")
                    if ((name.isEmpty() || isPlus.test(name))
                            && a0.getMaxAddressLineIndex() >= 0) {
                        String line0 = a0.getAddressLine(0);
                        if (line0 != null) {
                            String[] parts = line0.split(",");
                            for (String part : parts) {
                                String seg = part.trim();
                                if (seg.length() > 1 && !isPlus.test(seg) && !seg.matches("^[0-9].*")
                                        && !seg.toLowerCase(Locale.ENGLISH).contains("tehsil")
                                        && !seg.toLowerCase(Locale.ENGLISH).contains("district")) {
                                    name = seg;
                                    break;
                                }
                            }
                        }
                    }
                    if (isPlus.test(name)) name = "";

                    JSONObject o = new JSONObject();
                    o.put("name", name);
                    o.put("subLocality", subLocality != null ? subLocality : "");
                    o.put("locality", locality != null ? locality : "");
                    o.put("featureName", feature != null ? feature : "");
                    o.put("thoroughfare", thoroughfare != null ? thoroughfare : "");
                    o.put("premises", premises != null ? premises : "");
                    o.put("subAdminArea", subAdmin != null ? subAdmin : "");
                    o.put("adminArea", admin != null ? admin : "");
                    o.put("country", country != null ? country : "");
                    o.put("ok", true);
                    if (a0.getMaxAddressLineIndex() >= 0) {
                        o.put("addressLine", a0.getAddressLine(0) != null ? a0.getAddressLine(0) : "");
                    }
                    return o.toString();
                } catch (Exception e) {
                    try {
                        err.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
                        err.put("name", "");
                        return err.toString();
                    } catch (Exception e2) {
                        return "{\"error\":\"exception\",\"name\":\"\"}";
                    }
                }
            }

            @android.webkit.JavascriptInterface
            public void shareApp(String title, String text) {
                try {
                    final String t = title != null ? title : "SkyMeter";
                    final String body = text != null ? text : "Check out SkyMeter weather app";
                    runOnUiThread(() -> {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("text/plain");
                            send.putExtra(Intent.EXTRA_SUBJECT, t);
                            send.putExtra(Intent.EXTRA_TEXT, body);
                            Intent chooser = Intent.createChooser(send, t);
                            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(chooser);
                        } catch (Exception e) { /* ignore */ }
                    });
                } catch (Exception e) { /* ignore */ }
            }

            @android.webkit.JavascriptInterface
            public void openExternalUrl(String url) {
                try {
                    final String u = url != null ? url : "";
                    runOnUiThread(() -> {
                        try {
                            Uri uri = Uri.parse(u);
                            Intent i = new Intent(Intent.ACTION_VIEW, uri);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } catch (Exception e) {
                            try {
                                // Fallback: open https Play Store if market:// fails
                                String fallback = u;
                                if (u.startsWith("market://")) {
                                    fallback = "https://play.google.com/store/apps/details?id=com.skymeter.app";
                                }
                                Intent i2 = new Intent(Intent.ACTION_VIEW, Uri.parse(fallback));
                                i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i2);
                            } catch (Exception e2) { /* ignore */ }
                        }
                    });
                } catch (Exception e) { /* ignore */ }
            }

            @android.webkit.JavascriptInterface
            public void sendEmail(String to, String subject, String body) {
                try {
                    final String email = to != null ? to : "livingston7651@gmail.com";
                    final String sub = subject != null ? subject : "SkyMeter Feedback";
                    final String b = body != null ? body : "";
                    runOnUiThread(() -> {
                        try {
                            Intent i = new Intent(Intent.ACTION_SENDTO);
                            i.setData(Uri.parse("mailto:" + email));
                            i.putExtra(Intent.EXTRA_SUBJECT, sub);
                            i.putExtra(Intent.EXTRA_TEXT, b);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(Intent.createChooser(i, "Send feedback"));
                        } catch (Exception e) {
                            try {
                                Intent i2 = new Intent(Intent.ACTION_SEND);
                                i2.setType("message/rfc822");
                                i2.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                                i2.putExtra(Intent.EXTRA_SUBJECT, sub);
                                i2.putExtra(Intent.EXTRA_TEXT, b);
                                i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(Intent.createChooser(i2, "Send feedback"));
                            } catch (Exception e2) { /* ignore */ }
                        }
                    });
                } catch (Exception e) { /* ignore */ }
            }

            @android.webkit.JavascriptInterface
            public boolean hasGeocoder() {
                try {
                    return Geocoder.isPresent();
                } catch (Exception e) {
                    return false;
                }
            }
        }, "SkyMeterNative");

        webView.setWebViewClient(new WebViewClient() {
            
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                String u = url.toLowerCase();
                if (u.startsWith("mailto:") || u.startsWith("tel:") || u.startsWith("sms:")
                        || u.startsWith("market:") || u.startsWith("intent:")) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) { /* ignore */ }
                    return true; // never load inside WebView
                }
                if (u.contains("play.google.com") || u.contains("apps.apple.com")) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                        return true;
                    } catch (Exception e) { /* ignore */ }
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return false;
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";
                // Never load mailto/tel/market/intent inside WebView (ERR_UNKNOWN_URL_SCHEME)
                if ("mailto".equals(scheme) || "tel".equals(scheme) || "sms".equals(scheme)
                        || "market".equals(scheme) || "intent".equals(scheme)) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, uri);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) {
                        if ("mailto".equals(scheme)) {
                            try {
                                Intent i2 = new Intent(Intent.ACTION_SENDTO, uri);
                                i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i2);
                            } catch (Exception e2) { /* ignore */ }
                        }
                    }
                    return true;
                }
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    // External browser for http(s) opened from app links (rate/share store)
                    String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
                    if (host.contains("play.google.com") || host.contains("apps.apple.com")
                            || host.contains("skymeter")) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, uri);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                            return true;
                        } catch (Exception e) { /* fall through */ }
                    }
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                wakeWebView();
                injectSystemTheme();
                // Expose native geocoder availability to JS immediately
                view.evaluateJavascript(
                    "(function(){try{window.__skyMeterHasNative=true;window.__skyMeterNativeGeocoder=(typeof SkyMeterNative!=='undefined'&&!!SkyMeterNative.reverseGeocode);console.log('[NATIVE BRIDGE]',window.__skyMeterNativeGeocoder);}catch(e){}})();",
                    null
                );
                // Kick geolocation so system "Allow SkyMeter to access location?" appears
                view.evaluateJavascript(
                    "(function(){try{if(navigator.geolocation){navigator.geolocation.getCurrentPosition(function(){},function(){},{timeout:8000,maximumAge:0});}}catch(e){}})();",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestLocationPermission();
                }
            }
        });

        if (!hasLocationPermission()) {
            requestLocationPermission();
        }

        webView.loadUrl("file:///android_asset/www/index.html");
    }


    private boolean isSystemNightMode() {
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return night == Configuration.UI_MODE_NIGHT_YES;
    }

    private void injectSystemTheme() {
        if (webView == null) return;
        boolean night = isSystemNightMode();
        String js = "(function(){try{" +
            "window.__androidNightMode=" + (night ? "true" : "false") + ";" +
            "window.__androidThemeSource='native';" +
            "if(typeof applyTheme==='function'){" +
            "var p=null;try{p=localStorage.getItem('skymeter_theme');}catch(e){}" +
            "if(!p||p==='system'||p==='auto'){applyTheme('system');}" +
            "}" +
            "}catch(e){}})();";
        webView.evaluateJavascript(js, null);
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(
                this,
                new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                },
                REQ_LOCATION
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int r : grantResults) {
                if (r == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }
            if (pendingGeoCallback != null) {
                pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
            if (granted && webView != null) {
                webView.evaluateJavascript(
                    "(function(){try{" +
                    "if(typeof window.onAndroidLocationGranted==='function')window.onAndroidLocationGranted();" +
                    "else{if(typeof centerMapOnUserLocation==='function')centerMapOnUserLocation();if(typeof bootWeather==='function')bootWeather();}" +
                    "}catch(e){}})();",
                    null
                );
            }
        }
    }

    /** Force WebView to paint again after coming from background */
    private void wakeWebView() {
        if (webView == null) return;
        try {
            webView.onResume();
            webView.resumeTimers();
            webView.setVisibility(View.VISIBLE);
            webView.invalidate();
            webView.requestLayout();
            // JS repaint + visibility event (fixes long black screen)
            webView.evaluateJavascript(
                "(function(){" +
                "try{" +
                "document.body.style.display='none';" +
                "document.body.offsetHeight;" +
                "document.body.style.display='';" +
                "document.body.style.opacity='1';" +
                "document.body.style.visibility='visible';" +
                "window.dispatchEvent(new Event('resize'));" +
                "window.dispatchEvent(new Event('visibilitychange'));" +
                "if(typeof map!=='undefined'&&map&&map.resize){try{map.resize();}catch(e){}}" +
                "}catch(e){}" +
                "})();",
                null
            );
        } catch (Exception ignored) {}
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        injectSystemTheme();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            wakeWebView();
            // Second wake after a short delay (some devices need it)
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    wakeWebView();
                }
            }, 200);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    wakeWebView();
                }
            }, 600);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && webView != null) {
            wakeWebView();
        }
    }

    @Override
    protected void onPause() {
        // Do NOT call pauseTimers() — it causes long black screens on many phones
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // keep WebView state; no pauseTimers
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "(function(){try{if(typeof handleAndroidBack==='function'){return handleAndroidBack()?'1':'0';}return '0';}catch(e){return '0';}})();",
            new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    boolean handled = value != null && value.contains("1");
                    if (!handled) {
                        MainActivity.super.onBackPressed();
                    }
                }
            }
        );
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
