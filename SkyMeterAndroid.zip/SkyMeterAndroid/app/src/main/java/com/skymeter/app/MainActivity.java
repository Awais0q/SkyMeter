package com.skymeter.app;

import android.Manifest;
import android.content.Intent;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final int REQ_LOCATION = 1001;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageLoaded = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        // Dark bg so flash is not pure black/white mismatch
        webView.setBackgroundColor(0xFF0F172A);
        // HARDWARE can black-screen on some devices after pause; SOFTWARE more stable
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowFileAccessFromFileURLs(true);
        // Keep DOM active
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setOffscreenPreRaster(true);
        }

        
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openOsmMap(double lat, double lon, double zoom, String title) {
                runOnUiThread(() -> {
                    Intent i = new Intent(MainActivity.this, OsmMapActivity.class);
                    i.putExtra("lat", lat);
                    i.putExtra("lon", lon);
                    i.putExtra("zoom", zoom > 0 ? zoom : 9.0);
                    i.putExtra("title", title != null ? title : "SkyMeter");
                    startActivity(i);
                });
            }
        }, "SkyMeterNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                wakeWebView();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestLocationPermission();
                }
            }
        });

        if (!hasLocationPermission()) {
            requestLocationPermission();
        }

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(
                this,
                new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                },
                REQ_LOCATION
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int r : grantResults) {
                if (r == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }
            if (pendingGeoCallback != null) {
                pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
            if (granted && webView != null) {
                webView.evaluateJavascript(
                    "(function(){try{if(typeof bootWeather==='function')bootWeather();}catch(e){}})();",
                    null
                );
            }
        }
    }

    /** Force WebView to paint again after coming from background */
    private void wakeWebView() {
        if (webView == null) return;
        try {
            webView.onResume();
            webView.resumeTimers();
            webView.setVisibility(View.VISIBLE);
            webView.invalidate();
            webView.requestLayout();
            // JS repaint + visibility event (fixes long black screen)
            webView.evaluateJavascript(
                "(function(){" +
                "try{" +
                "document.body.style.display='none';" +
                "document.body.offsetHeight;" +
                "document.body.style.display='';" +
                "document.body.style.opacity='1';" +
                "document.body.style.visibility='visible';" +
                "window.dispatchEvent(new Event('resize'));" +
                "window.dispatchEvent(new Event('visibilitychange'));" +
                "if(typeof map!=='undefined'&&map&&map.resize){try{map.resize();}catch(e){}}" +
                "}catch(e){}" +
                "})();",
                null
            );
        } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            wakeWebView();
            // Second wake after a short delay (some devices need it)
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    wakeWebView();
                }
            }, 200);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    wakeWebView();
                }
            }, 600);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && webView != null) {
            wakeWebView();
        }
    }

    @Override
    protected void onPause() {
        // Do NOT call pauseTimers() — it causes long black screens on many phones
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // keep WebView state; no pauseTimers
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "(function(){try{if(typeof handleAndroidBack==='function'){return handleAndroidBack()?'1':'0';}return '0';}catch(e){return '0';}})();",
            new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    boolean handled = value != null && value.contains("1");
                    if (!handled) {
                        MainActivity.super.onBackPressed();
                    }
                }
            }
        );
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
